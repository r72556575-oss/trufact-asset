# TruFact daily Short — fully automatic (GitHub Actions)

Every day: verified fact → Hindi script (10 sentences) → Gemini Hindi voice (Puck) → music + sound effects → story.js → 3D-cartoon render → English captions → private upload scheduled for 7:30 PM IST.

**Every video:** ~45 seconds (`TARGET_SECONDS`), Hindi voice, background music bed + sound effects.

```
topic.py  → tts.py → audio_timing.py → sound.py → story_author.py → render.py → post.py → upload.py
(Gemini+Search) (Gemini TTS) (split/pad/fit 45s) (music+sfx) (LLM writes story.js)  (Chromium)  (PIL+ffmpeg) (Zapier or YouTube API)
```

## 1. Create the repo
1. New GitHub repo (public = free Actions minutes + 4-CPU runners). Upload everything from this zip (keep the `.github` folder).
2. Settings → Actions → General → Workflow permissions → **Read and write permissions**.

## 2. Secrets (Settings → Secrets and variables → Actions → *New repository secret*)
| Secret | Needed? | What / where to get it |
|---|---|---|
| `GEMINI_API_KEY` | **required** | Google AI Studio → Get API key. **Create a NEW key** (the old one was pasted in a chat). |
| `ZAPIER_WEBHOOK_URL` | required for `UPLOAD_BACKEND=zapier` (default) | URL of the Zap's *Webhooks by Zapier → Catch Hook* trigger (step 3). |
| `ANTHROPIC_API_KEY` | recommended | console.anthropic.com → API keys. Writes story.js with Claude (better scene code). Without it, Gemini 2.5 Pro is used. |
| `YT_CLIENT_ID`, `YT_CLIENT_SECRET`, `YT_REFRESH_TOKEN` | only for `UPLOAD_BACKEND=youtube` | Google Cloud Console → YouTube Data API v3 → OAuth client (Desktop). Then run `python3 tools/get_youtube_refresh_token.py <id> <secret>` on your PC. |

`GITHUB_TOKEN` is automatic. Optional repo **Variables** (same page, *Variables* tab): `UPLOAD_BACKEND` (`zapier`|`youtube`|`none`), `PRIVACY_MODE` (`schedule` = private + publishAt, `private` = stays private for you to review).

## 3. Why Zapier is the default upload path
YouTube's API says every video uploaded from an **unverified** API project (created after 28 Jul 2020) is **locked private**; lifting that needs Google's compliance audit. Zapier's YouTube app is already verified, which is why your manual uploads worked. So the workflow publishes the mp4 as a GitHub Release asset and calls a Zap:

1. Zapier → New Zap → trigger **Webhooks by Zapier → Catch Hook** (paid Zapier feature). Copy its URL into `ZAPIER_WEBHOOK_URL`.
2. Action **YouTube → Upload Video** with: Title = `title`, Description = `description`, Tags = `tags`, **Video = `video_url`**, Privacy = `privacy_status`, Publish At = `publish_at`, Notify subscribers = `notify_subscribers`, Made for kids = `made_for_kids`.
3. Run the workflow once manually, let Zapier receive the sample, map the fields, publish the Zap.

(If you later pass Google's audit, set variable `UPLOAD_BACKEND=youtube`.)

## 4. First run
Actions → **daily-short** → *Run workflow* → `dry_run = 1`. It builds the video and attaches `out/short.mp4` as an artifact, without uploading. Watch it, then run once with `dry_run = 0`. After that the cron (`30 6 * * *` UTC) runs daily; change the time in `.github/workflows/daily.yml`. Publish slot: `PUBLISH_HOUR_IST`/`PUBLISH_MIN_IST` (default 19:30).

## 4b. Music, sound effects, length, Hindi
- **Music + SFX** (`pipeline/sound.py`) are synthesized with numpy, so there is nothing to download and no copyright claim risk. Each video gets its own key/progression/BPM (seeded by the title). SFX are cued automatically: whoosh on every scene change, ding every 3rd scene, pop+ding on each comic panel, riser + sting into the final twist, ding at the end. The music/SFX duck under the voice. Tune with variables `MUSIC_GAIN` (default 1.4) and `SFX_GAIN` (0.5).
- **45 seconds:** the script must have 10 Hindi sentences and 115-170 Hindi words (checked before spending TTS quota). After TTS the voice is tempo-fitted (pitch preserving, ffmpeg `atempo`) to exactly 45 s when it is within about -15%/+25% of that; otherwise the log shows a WARNING. Change with variable `TARGET_SECONDS`.
- **Hindi voice in every video:** every narration sentence must be Devanagari (script check), and TTS always reads the Hindi text with the Puck voice. English is used only for captions.
- 10 beats = 5 TTS requests per video (was 4). Watch your Gemini TTS quota.

## 5. What was tested here, and what was NOT
| Part | Status |
|---|---|
| Audio trim/split/pad/concat + fit to 45 s | unit-tested on synthetic audio ✔ |
| Music bed + SFX + ducking | unit-tested (levels, no clipping, deterministic) ✔ — **how it sounds is for you to judge**; tune the gains |
| Captions, comic panels, ffmpeg mux (1080x1920, h264+aac) | tested end to end on synthetic frames ✔ |
| Publish-slot logic (7:30 PM IST, next-day rollover) | unit-tested ✔ |
| Orchestration wiring (incl. 45 s mp4 with music) | smoke-tested with fakes ✔ |
| story.js validator | tested on your soldier example (pass) and a broken copy (fail) ✔ |
| Gemini research / script / fact-check / TTS | **not run** (no network/keys where this was built) — expect small prompt or schema fixes on the first dry run |
| Chromium/three.js render in Actions | **not run** — the kit needs `npm`/`git` access (available on Actions) |
| Upload (Zapier hook, YouTube API) | **not run** |

## 6. Known limits (please read)
- **story.js is the weakest link.** Your kit's world is a hand-built Roman-bridge diorama with a Roman cast. An LLM can re-stage cameras, expressions and effects for each fact, but cannot invent new 3D assets, so all Shorts will look like that world. Each attempt is validated in seconds and by a 3-frame test render, with up to 3 retries. If you want different looks per category, add more worlds/casts to `kit/engine` (the LLM prompt picks them up automatically).
- **Render time:** ~675 rendered frames (45 s, every 2nd frame) at 4–7 s/frame; the runner shards across up to 4 CPUs (≈45–90 min). Free-tier job limit is far above that.
- Fact checking uses Gemini + Google Search twice (research, then a strict check). It reduces, not eliminates, wrong facts; use `PRIVACY_MODE=private` if you want to review before it goes public.
- Never commit keys. All keys live in GitHub Secrets only.
