#!/usr/bin/env python3
"""ONE-TIME, run on your own computer (only needed for UPLOAD_BACKEND=youtube).
  python3 tools/get_youtube_refresh_token.py <CLIENT_ID> <CLIENT_SECRET>
Opens a Google consent URL; paste the code back; prints the refresh token to store as the YT_REFRESH_TOKEN secret."""
import sys, urllib.parse, requests
cid, secret = sys.argv[1], sys.argv[2]
redirect = "http://localhost:8080/"
scope = "https://www.googleapis.com/auth/youtube.upload"
url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({
    "client_id": cid, "redirect_uri": redirect, "response_type": "code", "scope": scope,
    "access_type": "offline", "prompt": "consent"})
print("1) Open this URL, log in with the TruFact channel account, allow access:\n", url)
print("2) The browser will fail to load localhost - that is fine. Copy the value after 'code=' in the address bar.")
code = urllib.parse.unquote(input("code: ").strip())
r = requests.post("https://oauth2.googleapis.com/token", data={
    "code": code, "client_id": cid, "client_secret": secret, "redirect_uri": redirect, "grant_type": "authorization_code"})
print(r.json().get("refresh_token") or r.text)
