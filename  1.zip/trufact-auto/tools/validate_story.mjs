// usage: node tools/validate_story.mjs <path/to/story.js> <expectedTotalFrames>
// Imports a story.js and calls every export for every frame with a stub T, so errors surface in seconds
// (before any slow Chromium render).
import { pathToFileURL } from 'url';
import fs from 'fs';
import path from 'path';
const [,, file, expected] = process.argv;
const tmp = path.join(path.dirname(file), '_story_check.mjs');
fs.copyFileSync(file, tmp);
const out = { ok: false, errors: [] };
try {
  const S = await import(pathToFileURL(tmp).href + '?t=' + Date.now());
  for (const k of ['FPS', 'TOTAL', 'SHOTS', 'LIGHTS', 'lightFor', 'camAt', 'dofAt', 'worldAt', 'actorsAt', 'fxAt', 'shotAt'])
    if (!(k in S)) out.errors.push('missing export ' + k);
  if (!out.errors.length) {
    if (expected && Math.abs(S.TOTAL - +expected) > 2) out.errors.push(`TOTAL=${S.TOTAL} but narration needs ${expected} frames`);
    let prev = -1;
    for (const s of S.SHOTS) { if (s.a !== prev + 1) out.errors.push(`SHOTS not contiguous at ${s.id}: a=${s.a}, expected ${prev + 1}`); if (s.b < s.a) out.errors.push(`shot ${s.id} b<a`); prev = s.b; if (!S.LIGHTS[s.light]) out.errors.push(`shot ${s.id} uses unknown light ${s.light}`); }
    if (prev !== S.TOTAL - 1) out.errors.push(`SHOTS end at ${prev}, TOTAL-1 is ${S.TOTAL - 1}`);
    const T = new Proxy({}, { get: () => () => 0 });
    for (let f = 0; f < S.TOTAL && out.errors.length < 8; f++) {
      try {
        const sh = S.shotAt(f), c = S.camAt(f), L = S.lightFor(sh, f), d = S.dofAt(f);
        S.worldAt(f); S.actorsAt(f, T); S.fxAt(f, T);
        for (const v of [...c.pos, ...c.look, c.fov]) if (!Number.isFinite(v)) throw new Error('camera value is not finite');
        if (!L || !d) throw new Error('light or dof missing');
      } catch (e) { out.errors.push(`frame ${f}: ${e.message}`); }
    }
  }
  out.ok = out.errors.length === 0;
} catch (e) { out.errors.push('import failed: ' + e.message); }
try { fs.unlinkSync(tmp); } catch {}
console.log(JSON.stringify(out));
process.exit(out.ok ? 0 : 1);
