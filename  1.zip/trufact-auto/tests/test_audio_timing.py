import numpy as np
from pipeline import audio_timing as at

SR = 24000


def tone(sec, f=220):
    t = np.arange(int(SR * sec)) / SR
    return (9000 * np.sin(2 * np.pi * f * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 4 * t))).astype(np.float32)


def silence(sec):
    return np.zeros(int(SR * sec), dtype=np.float32)


def test_trim():
    x = np.concatenate([silence(0.5), tone(1.0), silence(0.7)])
    y = at.trim_silence(x, SR)
    assert 0.95 < len(y) / SR < 1.2


def test_split_finds_longest_middle_gap(tmp_path):
    # sentence A (2.0 s) | short gap 0.08 s inside A | long gap 0.35 s | sentence B (1.6 s)
    a = np.concatenate([tone(0.9), silence(0.08), tone(1.0), silence(0.35), tone(1.6)])
    first, second = at.split_at_longest_silence(a, SR)
    assert abs(len(first) / SR - (0.9 + 0.08 + 1.0 + 0.175)) < 0.08
    assert abs(len(second) / SR - (0.175 + 1.6)) < 0.08


def test_build_voice_8_scenes(tmp_path):
    paths = []
    for k in range(4):
        x = np.concatenate([silence(0.3), tone(1.4 + 0.1 * k), silence(0.3), tone(1.2), silence(0.25)])
        p = tmp_path / f"c{k}.wav"
        at.write_wav(p, x, SR)
        paths.append(p)
    t = at.build_voice(paths, tmp_path / "voice.wav")
    assert len(t["sentences"]) == 8 and len(t["scenes"]) == 8
    assert t["scenes"][0]["fa"] == 0 and t["scenes"][-1]["fb"] == t["frames"] - 1
    for a, b in zip(t["scenes"], t["scenes"][1:]):
        assert b["fa"] == a["fb"] + 1
    assert all(s["e"] > s["s"] for s in t["sentences"])
