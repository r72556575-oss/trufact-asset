"""Runs tests without pytest (fallback): python3 tests/run_plain.py"""
import importlib, inspect, sys, tempfile, pathlib, traceback
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
fails = 0
for mod in sys.argv[1:] or ["tests.test_audio_timing", "tests.test_post", "tests.test_sound"]:
    try:
        m = importlib.import_module(mod)
    except ModuleNotFoundError as e:
        print("skip", mod, e); continue
    for name, fn in inspect.getmembers(m, inspect.isfunction):
        if not name.startswith("test_"): continue
        with tempfile.TemporaryDirectory() as d:
            try:
                fn(pathlib.Path(d)) if "tmp_path" in inspect.signature(fn).parameters else fn()
                print("PASS", mod, name)
            except Exception:
                fails += 1; print("FAIL", mod, name); traceback.print_exc()
sys.exit(1 if fails else 0)
