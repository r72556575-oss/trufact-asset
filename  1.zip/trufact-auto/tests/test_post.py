import subprocess, json
import numpy as np
from PIL import Image
from pipeline import post, audio_timing as at, config

SR = 24000


def test_caption_groups_three_words():
    g = post.caption_groups(["one two three four five"], [{"s": 1.0, "e": 3.0}])
    assert [x["words"] for x in g] == [["one", "two", "three"], ["four", "five"]]
    assert g[0]["s"] == 1.0 and g[-1]["e"] <= 3.0 + 0.01


def test_encode_end_to_end(tmp_path):
    # 3 s of synthetic frames + synthetic voice, 2 sentences, 1 panel
    fr = tmp_path / "frames"; fr.mkdir()
    n = 90
    for f in range(n):
        Image.new("RGB", (1080, 1920), (30 + f, 90, 160)).save(fr / f"f{f:04d}.jpg", quality=90)
    t = np.arange(SR * 3) / SR
    at.write_wav(tmp_path / "v.wav", (8000 * np.sin(2 * np.pi * 300 * t)).astype(np.float32), SR)
    timing = {"sentences": [{"i": 0, "s": 0.2, "e": 1.3}, {"i": 1, "s": 1.6, "e": 2.8}], "scenes": []}
    out = tmp_path / "o.mp4"
    post.encode(fr, n, tmp_path / "v.wav", out, ["This is the first caption", "And a second one"], timing,
                [{"sentence": 0, "text": "30 YEARS"}])
    info = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=width,height,codec_name",
                           "-of", "json", str(out)], capture_output=True, text=True).stdout
    streams = json.loads(info)["streams"]
    assert any(s.get("codec_name") == "h264" and s["width"] == 1080 and s["height"] == 1920 for s in streams)
    assert any(s.get("codec_name") == "aac" for s in streams)
    # a captioned frame must differ from the plain background
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", "0.8", "-i", str(out), "-frames:v", "1", str(tmp_path / "s.png")], check=True)
    im = np.asarray(Image.open(tmp_path / "s.png").convert("RGB")).astype(int)
    assert (im[int(1920 * .72):int(1920 * .78)] > 240).any() or (im[int(1920*.72):int(1920*.78)].max(axis=2) > 220).any()


def test_publish_slot():
    from datetime import datetime, timezone, timedelta
    from pipeline import upload
    ist = timezone(timedelta(hours=5, minutes=30))
    early = datetime(2026, 11, 10, 9, 0, tzinfo=ist)       # 9 AM IST -> same day 19:30
    s = upload.next_publish_time(early)
    assert (s.day, s.hour, s.minute) == (10, 19, 30)
    late = datetime(2026, 11, 10, 19, 20, tzinfo=ist)       # only 10 min to the slot -> tomorrow
    s2 = upload.next_publish_time(late)
    assert s2.day == 11 and s2.hour == 19
    assert upload.publish_iso_utc(s) == "2026-11-10T14:00:00Z"
