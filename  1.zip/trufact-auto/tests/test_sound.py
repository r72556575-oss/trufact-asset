import numpy as np
from pipeline import sound, audio_timing as at, config

SR = 24000


def _timing(n=10, each=4.2):
    sents, t = [], 0.15
    for i in range(n):
        sents.append({"i": i, "s": round(t, 3), "e": round(t + each, 3)}); t += each + 0.3
    return at.make_timing(SR, t + 0.5, sents)


def test_mix_has_music_and_sfx_and_no_clipping(tmp_path):
    tm = _timing()
    v = (6000 * np.sin(2 * np.pi * 250 * np.arange(int(SR * tm["duration"])) / SR)).astype(np.float32)
    at.write_wav(tmp_path / "v.wav", v, SR)
    lv = sound.make_mix(tmp_path / "v.wav", tmp_path / "m.wav", tm, [{"sentence": 2, "text": "X"}], "seed")
    assert lv["music_rms"] > 0.003 and lv["sfx_rms"] > 0.0005 and lv["voice_rms"] > 0.01
    m, sr = at.read_wav(tmp_path / "m.wav")
    assert sr == 48000 and abs(len(m) / sr - tm["duration"]) < 0.05
    assert np.abs(m).max() <= 32767 and np.isfinite(m).all()


def test_music_is_deterministic_per_seed():
    a = sound.music_bed(6, sound._rng("same")); b = sound.music_bed(6, sound._rng("same")); c = sound.music_bed(6, sound._rng("other"))
    assert np.allclose(a, b) and not np.allclose(a, c)


def test_fit_to_45s(tmp_path):
    tm = _timing(each=4.6)                       # ~ 49 s -> must be sped up to 45 s
    x = (6000 * np.sin(2 * np.pi * 250 * np.arange(int(SR * tm["duration"])) / SR)).astype(np.float32)
    at.write_wav(tmp_path / "v.wav", x, SR)
    new = at.fit_to_target(tmp_path / "v.wav", tm, 45)
    assert abs(new["duration"] - 45) < 0.2 and new["scenes"][-1]["fb"] == new["frames"] - 1
    y, sr = at.read_wav(tmp_path / "v.wav")
    assert abs(len(y) / sr - 45) < 0.3
