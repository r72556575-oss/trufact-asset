"""Wiring smoke test with fakes for Gemini/story/render (no network): python3 tests/smoke_run.py"""
import sys, pathlib, tempfile, os
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
tmp = pathlib.Path(tempfile.mkdtemp())
os.environ.update(WORK_DIR=str(tmp / "work"), OUT_DIR=str(tmp / "out"), DRY_RUN="1")
import numpy as np
from PIL import Image
from pipeline import config, topic, tts, story_author, render, run, audio_timing as at
config.DRY_RUN = True
SR = 24000
tone = lambda s: (9000 * np.sin(2 * np.pi * 220 * np.arange(int(SR * s)) / SR)).astype(np.float32)
sil = lambda s: np.zeros(int(SR * s), dtype=np.float32)
topic.make_topic = lambda override="": {"category": "science", "title": "टेस्ट", "fact": "f", "description": "d", "tags": ["a"],
    "sentences": [{"hi": "क", "en": f"Caption number {i} here today"} for i in range(10)], "panels": [{"sentence": 1, "text": "30 YEARS"}]}
def fake_chunks(sents, outdir):
    ps = []
    for k in range(5):
        p = outdir / f"c{k}.wav"; at.write_wav(p, np.concatenate([sil(.2), tone(4.3), sil(.35), tone(4.1), sil(.2)]), SR); ps.append(p)
    return ps
tts.synth_chunks = fake_chunks
render.setup_project = lambda p: (p / "web").mkdir(parents=True, exist_ok=True)
story_author.author = lambda *a, **k: None
def fake_render(project, total):
    d = project / "frames"; d.mkdir(parents=True, exist_ok=True)
    for f in range(total): Image.new("RGB", (1080, 1920), (20, 60 + f % 150, 120)).save(d / f"f{f:04d}.jpg", quality=80)
    return d
render.render_all = fake_render
run.main()
print("SMOKE OK:", sorted(p.name for p in (tmp / "out").iterdir()))
