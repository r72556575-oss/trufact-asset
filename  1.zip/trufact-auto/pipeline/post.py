"""Step 5: English captions (3 words per group, current word yellow, thick black stroke, FreeSansBold),
procedural 2D comic-panel inserts (supersampled 2x), voice mux, 1080x1920 h264 crf19 + aac.
Frames in -> PIL overlay -> raw RGB piped into ffmpeg."""
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from . import config

W, H = 1080, 1920
FONT_PATHS = ["/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def _font(size):
    for p in FONT_PATHS:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def caption_groups(sentences_en, scenes_timing, per_group=3):
    """-> list of {s, e, words:[...]} ; words of a sentence are spread evenly across the spoken part of it."""
    groups = []
    for sent, tm in zip(sentences_en, scenes_timing):
        words = sent.split()
        if not words:
            continue
        dur = max(tm["e"] - tm["s"], 0.3)
        per = dur / len(words)
        for g in range(0, len(words), per_group):
            ws = words[g:g + per_group]
            groups.append({"s": tm["s"] + g * per, "e": tm["s"] + (g + len(ws)) * per, "words": ws,
                           "first": tm["s"] + g * per, "per": per})
    for a, b in zip(groups, groups[1:]):  # no flicker between groups
        a["e"] = max(a["e"], min(b["s"], a["e"] + 0.15))
    return groups


def draw_caption(img, group, t, font):
    d = ImageDraw.Draw(img)
    cur = min(int((t - group["first"]) / group["per"]), len(group["words"]) - 1)
    cur = max(0, cur)
    words = [w.upper() for w in group["words"]]
    space = font.getlength(" ")
    widths = [font.getlength(w) for w in words]
    total = sum(widths) + space * (len(words) - 1)
    if total > W - 80:  # too wide: stack on two lines
        lines = [words[:2], words[2:]] if len(words) > 2 else [words]
    else:
        lines = [words]
    y = int(H * 0.70)
    idx = 0
    for line in lines:
        lw = sum(font.getlength(w) for w in line) + space * (len(line) - 1)
        x = (W - lw) / 2
        for w in line:
            fill = "#ffe11a" if idx == cur else "#ffffff"
            d.text((x, y), w, font=font, fill=fill, stroke_width=12, stroke_fill="#000000")
            x += font.getlength(w) + space
            idx += 1
        y += int(font.size * 1.15)


def panel_image(text, pop):
    """Comic panel insert (supersampled 2x). pop in 0..1 drives a springy scale-in."""
    S = 2
    pw, ph = 760 * S, 330 * S
    im = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    r = 40 * S
    d.rounded_rectangle((12 * S, 12 * S, pw - 12 * S, ph - 12 * S), r, fill="#fff3b0", outline="#111111", width=12 * S)
    for yy in range(40 * S, ph - 30 * S, 34 * S):          # halftone dots
        for xx in range(40 * S + (yy // (34 * S) % 2) * 17 * S, pw - 30 * S, 34 * S):
            d.ellipse((xx, yy, xx + 9 * S, yy + 9 * S), fill="#ffd54a")
    f = _font(int(130 * S))
    while f.getlength(text.upper()) > pw - 120 * S and f.size > 40:
        f = _font(f.size - 6)
    tw = f.getlength(text.upper())
    d.text(((pw - tw) / 2, ph / 2 - f.size * 0.55), text.upper(), font=f, fill="#d62828",
           stroke_width=8 * S, stroke_fill="#111111")
    k = 1.0 + 0.18 * (1 - pop) if pop >= 1 else (0.6 + 0.55 * pop - 0.15 * pop * pop)
    k = max(0.3, min(1.15, k))
    im = im.resize((int(pw / S * k), int(ph / S * k)), Image.LANCZOS)
    return im


def panel_alpha(t, a, b):
    """0..1 pop-in over 0.25 s, hold, quick out over 0.15 s."""
    if t < a or t > b:
        return None
    if t < a + 0.25:
        return (t - a) / 0.25
    if t > b - 0.15:
        return max(0.0, (b - t) / 0.15)
    return 1.0


def encode(frames_dir, n_frames, voice_wav, out_mp4, sentences_en, timing, panels):
    frames_dir = Path(frames_dir)
    groups = caption_groups(sentences_en, timing["sentences"])
    font = _font(104)
    sc = timing["scenes"]
    panel_spans = [(p["text"], timing["sentences"][p["sentence"]]["s"] + 0.15,
                    timing["sentences"][p["sentence"]]["e"] - 0.1) for p in panels
                   if isinstance(p.get("sentence"), int) and 0 <= p["sentence"] < len(timing["sentences"])]
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
           "-r", str(config.FPS), "-i", "-", "-i", str(voice_wav), "-map", "0:v:0", "-map", "1:a:0",
           "-af", "loudnorm=I=-14:TP=-1.5:LRA=7", "-c:v", "libx264", "-preset", "medium", "-crf", "19",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest",
           "-movflags", "+faststart", str(out_mp4)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for f in range(n_frames):
            p = frames_dir / f"f{f:04d}.jpg"
            if not p.exists():  # holds the previous frame if a render frame is missing
                p = frames_dir / f"f{max(0, f - 1):04d}.jpg"
            img = Image.open(p).convert("RGB")
            if img.size != (W, H):
                img = img.resize((W, H), Image.LANCZOS)
            t = f / config.FPS
            for text, a, b in panel_spans:
                pop = panel_alpha(t, a, b)
                if pop is not None:
                    pim = panel_image(text, pop)
                    img.paste(pim, ((W - pim.width) // 2, int(H * 0.14)), pim)
            g = next((g for g in groups if g["s"] <= t < g["e"]), None)
            if g:
                draw_caption(img, g, t, font)
            proc.stdin.write(img.tobytes())
            if f > 0 and f % 300 == 0:
                print(f"encoded {f}/{n_frames}")
    finally:
        proc.stdin.close()
        rc = proc.wait()
    if rc != 0:
        raise RuntimeError("ffmpeg encode failed")
    return out_mp4
