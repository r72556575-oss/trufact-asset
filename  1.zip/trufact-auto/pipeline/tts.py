"""Step 2: Gemini TTS -> WAV (24 kHz mono 16-bit). 4 chunks of 2 sentences each."""
import base64
import re
import struct
import wave
from pathlib import Path
from . import config, gemini


def _rate_from_mime(mime: str) -> int:
    m = re.search(r"rate=(\d+)", mime or "")
    return int(m.group(1)) if m else 24000


def synth(text: str, out_wav: Path) -> Path:
    body = {
        "contents": [{"parts": [{"text": f"{config.TTS_PROMPT}\n{text}"}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": config.TTS_VOICE}}},
        },
    }
    last = None
    for model in [config.TTS_MODEL] + config.TTS_FALLBACK_MODELS:
        try:
            resp = gemini.generate(model, body, tries=4)
            part = resp["candidates"][0]["content"]["parts"][0]["inlineData"]
            pcm = base64.b64decode(part["data"])
            rate = _rate_from_mime(part.get("mimeType", ""))
            out_wav.parent.mkdir(parents=True, exist_ok=True)
            with wave.open(str(out_wav), "wb") as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(pcm)
            return out_wav
        except Exception as e:  # quota / model name / empty audio: try next model
            last = e
    raise RuntimeError(f"TTS failed on all models: {last}")


def synth_chunks(sentences_hi: list, outdir: Path) -> list:
    """sentences_hi: 8 Hindi sentences -> 4 wav files (2 sentences each)."""
    paths = []
    for i in range(0, len(sentences_hi), 2):
        text = " ".join(sentences_hi[i:i + 2])
        paths.append(synth(text, outdir / f"chunk{i // 2}.wav"))
    return paths
