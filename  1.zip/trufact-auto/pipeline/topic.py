"""Step 1-2: pick a rotating category, research ONE verified fact with Google Search grounding,
write the Hindi narration (8 sentences) + English captions, then fact-check the script."""
import json
import re
from . import config, gemini

DEVANAGARI = re.compile(r"[\u0900-\u097F]")


def load_history() -> list:
    if config.HISTORY.exists():
        return json.loads(config.HISTORY.read_text(encoding="utf-8"))
    return []


def save_history(items: list) -> None:
    config.HISTORY.parent.mkdir(parents=True, exist_ok=True)
    config.HISTORY.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")


def pick_category(history: list) -> str:
    return config.CATEGORIES[len(history) % len(config.CATEGORIES)]


def _json_from(text: str):
    text = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1).strip()
    start, end = text.find("{"), text.rfind("}")
    return json.loads(text[start:end + 1])


def research(category: str, avoid: list, override: str = "") -> dict:
    ask = (f"Topic requested by the channel owner: {override}\n" if override else
           f"Category for today: {category}.\n")
    prompt = (
        f"{ask}Find ONE surprising but TRUE, well-documented fact for a 30-second YouTube Short for a Hindi-speaking "
        "Indian audience (channel 'TruFact'). Use Google Search. Rules: no politics, nothing graphic, no viral legends "
        "presented as fact, nothing about living people. The fact must be confirmed by at least 2 independent reliable "
        f"sources. Do NOT repeat any of these earlier facts: {json.dumps(avoid[-60:], ensure_ascii=False)}.\n"
        "Reply in plain English: the fact in 3-4 sentences with exact numbers, the 2+ sources by name, and any caveat "
        "(for example if the story is only a popular claim).")
    resp = gemini.generate(config.TEXT_MODEL, {
        "contents": [{"parts": [{"text": prompt}]}],
        "tools": [{"google_search": {}}],
    })
    return {"text": gemini.text_of(resp), "sources": gemini.sources_of(resp)}


WRITE_SCHEMA = """Return ONLY JSON:
{
 "title": "Hindi title, curiosity hook, under 60 characters (no #Shorts, no digits)",
 "fact": "one-sentence English summary of the fact",
 "sentences": [ exactly __N__ objects { "hi": "...", "en": "..." } ],
 "panels": [ 0-2 objects { "sentence": 0-__M__, "text": "SHORT ENGLISH LABEL like '30 YEARS' (max 14 chars)" } ],
 "description": "2-3 Hindi lines, then a line of hashtags: #TruFact #HindiFacts #Facts #Shorts",
 "tags": [8-12 English or Hindi keywords]
}"""


def write_script(category: str, research_text: str, issues: list) -> dict:
    schema = WRITE_SCHEMA.replace("__N__", str(config.NUM_SENTENCES)).replace("__M__", str(config.NUM_SENTENCES - 1))
    prompt = (
        f"Research notes (trust only these facts):\n{research_text}\n\n"
        f"Write a {int(config.TARGET_SECONDS)}-second narration for a vertical cartoon Short, spoken fully in HINDI.\n"
        f"- Exactly {config.NUM_SENTENCES} sentences. Sentence 1 is a hook question or shocking statement. The last sentence is the payoff/twist.\n"
        "- 'hi': Hindi in Devanagari, spoken style, 11-16 words each (about 130-150 Hindi words in total). Write ALL numbers as Hindi words (no digits), "
        "no emojis, no English words except unavoidable names.\n"
        "- 'en': short natural English caption of the same sentence, 6-12 words, no emojis.\n"
        "- If the notes say it is a popular claim, say 'कहा जाता है'.\n"
        f"- Category: {category}.\n"
        + (f"- A fact-checker found problems, fix them: {json.dumps(issues, ensure_ascii=False)}\n" if issues else "")
        + schema)
    resp = gemini.generate(config.TEXT_MODEL, {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.7},
    })
    return _json_from(gemini.text_of(resp))


def check_shape(d: dict) -> list:
    problems = []
    s = d.get("sentences") or []
    if len(s) != config.NUM_SENTENCES:
        problems.append(f"need exactly {config.NUM_SENTENCES} sentences, got {len(s)}")
    for i, x in enumerate(s):
        hi, en = x.get("hi", ""), x.get("en", "")
        if not DEVANAGARI.search(hi):
            problems.append(f"sentence {i}: 'hi' is not Devanagari")
        if re.search(r"\d", hi):
            problems.append(f"sentence {i}: digits in Hindi text, write numbers as words")
        if not en.strip():
            problems.append(f"sentence {i}: missing English caption")
    words = sum(len(x.get("hi", "").split()) for x in s)
    if not (config.MIN_HI_WORDS <= words <= config.MAX_HI_WORDS):
        problems.append(f"Hindi narration has {words} words; need {config.MIN_HI_WORDS}-{config.MAX_HI_WORDS} for a {int(config.TARGET_SECONDS)} s video")
    if not d.get("title"):
        problems.append("missing title")
    return problems


def fact_check(script: dict, research_text: str) -> dict:
    prompt = (
        "You are a strict fact-checker. Use Google Search. Check every claim in this Hindi/English script "
        "against reliable sources and against the research notes.\n"
        f"Research notes:\n{research_text}\n\nScript (English captions): "
        f"{json.dumps([x['en'] for x in script['sentences']], ensure_ascii=False)}\n"
        'Reply ONLY JSON: {"ok": true|false, "issues": ["short description of each wrong or unsupported claim"]}')
    resp = gemini.generate(config.TEXT_MODEL, {
        "contents": [{"parts": [{"text": prompt}]}],
        "tools": [{"google_search": {}}],
    })
    try:
        return _json_from(gemini.text_of(resp))
    except Exception:
        return {"ok": False, "issues": ["fact-checker returned unreadable output"]}


def make_topic(override: str = "", max_rounds: int = 3) -> dict:
    history = load_history()
    category = pick_category(history)
    avoid = [h.get("fact", "") for h in history]
    notes = research(category, avoid, override)
    issues = []
    for _ in range(max_rounds):
        script = write_script(category, notes["text"], issues)
        issues = check_shape(script)
        if issues:
            continue
        verdict = fact_check(script, notes["text"])
        if verdict.get("ok"):
            script.update(category=category, sources=notes["sources"], research=notes["text"])
            return script
        issues = verdict.get("issues", ["fact-check failed"])
    raise RuntimeError(f"Could not produce a verified script. Last issues: {issues}")
