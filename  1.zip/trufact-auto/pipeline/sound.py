"""Step 3b: background music + sound effects, fully synthesized (numpy) -> no licensing problems, no downloads.
Music: a looping bed (pluck bass + chords + light drums, key/progression/BPM chosen per video by a seeded RNG).
SFX: auto-cued from the scene timing (whoosh at scene changes, pop+ding at comic panels, riser + sting at the
final twist). The bed ducks under the Hindi voice. Output: mix_raw 48 kHz mono wav (post.encode loudnorms it)."""
import hashlib
import subprocess
import wave
import numpy as np
from . import config

SR = 48000


def _rng(seed_text):
    return np.random.default_rng(int(hashlib.sha256(seed_text.encode()).hexdigest()[:8], 16))


def _lp(x, cutoff):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR)
    return np.fft.irfft(X / (1 + (f / cutoff) ** 4), len(x)).astype(np.float32)


def _hp(x, cutoff):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR)
    return np.fft.irfft(X * (1 - 1 / (1 + (f / cutoff) ** 4)), len(x)).astype(np.float32)


def _env(n, a=0.005, r=0.2):
    t = np.arange(n) / SR
    return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / r)


midi = lambda m: 440 * 2 ** ((m - 69) / 12)


def _place(buf, sig, t0, gain=1.0):
    i = int(t0 * SR); j = min(len(buf), i + len(sig))
    if 0 <= i < len(buf) and j > i:
        buf[i:j] += sig[: j - i] * gain


def load_voice(path, n):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                         capture_output=True, check=True).stdout
    v = np.frombuffer(raw, np.float32).copy()
    out = np.zeros(n, np.float32); out[:min(n, len(v))] = v[:n]
    return out


# ---------- instruments ----------
def pluck(f, dur=0.35, bright=0.5):
    n = int(dur * SR); t = np.arange(n) / SR
    s = sum((bright ** k) * np.sin(2 * np.pi * f * (k + 1) * t) / (k + 1) for k in range(6))
    return (s * _env(n, 0.003, dur * 0.35)).astype(np.float32)


def pad(freqs, dur):
    n = int(dur * SR); t = np.arange(n) / SR; s = np.zeros(n)
    for f in freqs:
        s += np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 2 * t + 0.3)
    a = np.minimum(1, t / 0.12) * np.clip((dur - t) / 0.2, 0, 1)
    return _lp((s * a).astype(np.float32), 1600) / len(freqs)


def drum(kind, rng):
    if kind == "kick":
        n = int(0.3 * SR); t = np.arange(n) / SR; f = 48 + 90 * np.exp(-t * 30)
        return (np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 10)).astype(np.float32)
    if kind == "hat":
        n = int(0.06 * SR); t = np.arange(n) / SR
        return (_hp(rng.standard_normal(n).astype(np.float32), 6000) * np.exp(-t * 70) * 0.5).astype(np.float32)
    n = int(0.16 * SR); t = np.arange(n) / SR
    s = rng.standard_normal(n) * np.exp(-t * 30) * 0.6 + np.sin(2 * np.pi * 200 * t) * np.exp(-t * 22) * 0.5
    return _hp(s.astype(np.float32), 300)


PROGRESSIONS = [  # (bass root midi, chord midis)
    [(57, [57, 60, 64]), (53, [53, 57, 60]), (55, [55, 59, 62]), (52, [52, 56, 59])],   # Am F G E
    [(60, [60, 64, 67]), (55, [55, 59, 62]), (57, [57, 60, 64]), (53, [53, 57, 60])],   # C G Am F
    [(50, [50, 53, 57]), (46, [46, 50, 53]), (53, [53, 57, 60]), (48, [48, 52, 55])],   # Dm Bb F C
    [(52, [52, 55, 59]), (48, [48, 52, 55]), (50, [50, 54, 57]), (55, [55, 59, 62])],   # Em C D G
]


def music_bed(duration, rng):
    N = int(duration * SR)
    music = np.zeros(N, np.float32)
    bpm = int(rng.integers(98, 118)); beat = 60 / bpm
    prog = PROGRESSIONS[int(rng.integers(0, len(PROGRESSIONS)))]
    end = duration - 0.6
    bar, tt = 0, 0.0
    while tt < end:
        root, ch = prog[bar % 4]
        _place(music, pad([midi(m) for m in ch], beat * 4 * 0.98), tt, 0.10)
        for b in range(4):
            tb = tt + b * beat
            if tb >= end:
                break
            _place(music, drum("kick" if b % 2 == 0 else "snare", rng), tb, 0.5 if b % 2 == 0 else 0.28)
            _place(music, drum("hat", rng), tb + beat / 2, 0.35)
            _place(music, pluck(midi(root - 12), 0.4, 0.4), tb, 0.33)
            _place(music, pluck(midi(ch[(b + bar) % 3] + 12), 0.22, 0.6), tb + beat / 2, 0.12)
        bar += 1; tt += beat * 4
    fade = int(1.2 * SR)  # musical tail-out
    music[-fade:] *= np.linspace(1, 0, fade) ** 2
    return music


# ---------- sfx ----------
def whoosh(d, rng):
    n = int(d * SR); t = np.arange(n) / SR
    return (_lp(rng.standard_normal(n).astype(np.float32), 1800) * np.sin(np.pi * t / d) ** 2 * 0.6).astype(np.float32)


def pop():
    n = int(0.12 * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * (300 + 700 * np.exp(-t * 40)) * t) * np.exp(-t * 28)).astype(np.float32)


def ding():
    n = int(1.0 * SR); t = np.arange(n) / SR
    return (sum(np.sin(2 * np.pi * f * t) * np.exp(-t * k) for f, k in [(1568, 4), (2349, 6), (3136, 9)]) * 0.3).astype(np.float32)


def riser(d, rng):
    n = int(d * SR); t = np.arange(n) / SR
    tone = np.sin(2 * np.pi * np.cumsum(200 + 900 * (t / d) ** 2) / SR)
    noise = _hp(rng.standard_normal(n).astype(np.float32), 2000) * 0.3
    return ((tone * 0.4 + noise) * (t / d) ** 1.5).astype(np.float32)


def sting(rng):
    n = int(1.6 * SR); t = np.arange(n) / SR
    low = np.sin(2 * np.pi * 55 * t) * np.exp(-t * 2.2)
    hit = _lp(rng.standard_normal(n).astype(np.float32), 900) * np.exp(-t * 7) * 0.7
    chord = sum(np.sin(2 * np.pi * midi(m) * t) for m in (57, 60, 64)) * np.exp(-t * 3) * 0.25
    return (low + hit + chord).astype(np.float32)


def sfx_track(duration, timing, panels, rng):
    N = int(duration * SR); sfx = np.zeros(N, np.float32)
    sc = timing["scenes"]; sents = timing["sentences"]
    for i, s in enumerate(sc):
        if i == 0:
            _place(sfx, whoosh(0.5, rng), 0.05, 0.4)
            continue
        _place(sfx, whoosh(0.45, rng), max(0.0, s["a"] - 0.1), 0.5 if i % 2 else 0.4)
        if i % 3 == 0:
            _place(sfx, ding(), s["a"] + 0.05, 0.3)
    for p in panels:
        k = p.get("sentence")
        if isinstance(k, int) and 0 <= k < len(sents):
            t0 = sents[k]["s"] + 0.15
            _place(sfx, pop(), t0, 0.8); _place(sfx, ding(), t0 + 0.05, 0.4)
    last = sents[-1]["s"]
    _place(sfx, riser(min(1.3, last), rng), max(0.0, last - 1.3), 0.45)   # build-up into the twist
    _place(sfx, sting(rng), last, 0.8)
    _place(sfx, ding(), sents[-1]["e"] + 0.1, 0.35)
    return sfx


def make_mix(voice_wav, out_wav, timing, panels, seed):
    rng = _rng(seed)
    duration = timing["duration"]
    N = int(duration * SR)
    voice = load_voice(voice_wav, N)
    music = music_bed(duration, rng)
    sfx = sfx_track(duration, timing, panels, rng)
    ve = np.abs(voice); k = int(0.06 * SR)
    ve = np.convolve(ve, np.ones(k) / k, "same")
    duck = 1 - 0.55 * np.clip(ve / (max(ve.max(), 1e-6) * 0.25), 0, 1)    # music/sfx dip while Hindi voice speaks
    sfx_duck = 1 - 0.25 * np.clip(ve / (max(ve.max(), 1e-6) * 0.25), 0, 1)
    mix = voice + music * duck * config.MUSIC_GAIN + sfx * sfx_duck * config.SFX_GAIN
    mix = np.tanh(mix * 0.95) / np.tanh(0.95)
    f = int(0.04 * SR); mix[-f:] *= np.linspace(1, 0, f)
    pcm = (np.clip(mix, -1, 1) * 32767).astype(np.int16)
    with wave.open(str(out_wav), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    return {"music_rms": float(np.sqrt((music ** 2).mean())), "sfx_rms": float(np.sqrt((sfx ** 2).mean())),
            "voice_rms": float(np.sqrt((voice ** 2).mean()))}
