"""Tiny Gemini REST client with retry/backoff (no SDK needed)."""
import time
import requests
from . import config


class GeminiError(RuntimeError):
    pass


def generate(model: str, body: dict, tries: int = 5, timeout: int = 300) -> dict:
    if not config.GEMINI_API_KEY:
        raise GeminiError("GEMINI_API_KEY is not set")
    url = f"{config.GEMINI_BASE}/models/{model}:generateContent"
    last = None
    for i in range(tries):
        r = requests.post(url, json=body, timeout=timeout,
                          headers={"x-goog-api-key": config.GEMINI_API_KEY, "Content-Type": "application/json"})
        if r.status_code == 200:
            return r.json()
        last = f"{r.status_code}: {r.text[:400]}"
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(min(60, 5 * 2 ** i))
            continue
        break  # 400/403/404 are not worth retrying
    raise GeminiError(f"{model} failed: {last}")


def text_of(resp: dict) -> str:
    parts = (resp.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
    return "".join(p.get("text", "") for p in parts)


def sources_of(resp: dict) -> list:
    chunks = (resp.get("candidates") or [{}])[0].get("groundingMetadata", {}).get("groundingChunks", [])
    out = []
    for c in chunks:
        w = c.get("web") or {}
        if w.get("uri"):
            out.append({"title": w.get("title", ""), "uri": w["uri"]})
    return out
