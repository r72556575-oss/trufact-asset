"""Step 6: upload private + publishAt (set AT UPLOAD TIME: a video that has been public once can never be scheduled).

Backends
- zapier : publishes the mp4 as a GitHub Release asset (public URL) and POSTs JSON to a Zapier 'Catch Hook'.
           The Zap then runs YouTube 'Upload Video' (Zapier's own verified YouTube app, so no API audit needed).
- youtube: direct YouTube Data API (resumable upload). NOTE: API projects that have not passed Google's compliance
           audit get every upload LOCKED PRIVATE, whatever publishAt says. Use only if your project is audited.
- none   : just keep the mp4 as a workflow artifact."""
import json
import os
import subprocess
from datetime import datetime, timedelta, timezone
import requests
from . import config

IST = timezone(timedelta(hours=5, minutes=30))


def next_publish_time(now=None) -> datetime:
    now = (now or datetime.now(timezone.utc)).astimezone(IST)
    slot = now.replace(hour=config.PUBLISH_HOUR_IST, minute=config.PUBLISH_MIN_IST, second=0, microsecond=0)
    if slot - now < timedelta(minutes=config.MIN_LEAD_MINUTES):
        slot += timedelta(days=1)
    return slot


def publish_iso_utc(slot: datetime) -> str:
    return slot.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _release(mp4_path, tag):
    """GitHub Release asset on the current repo (needs GITHUB_TOKEN + GITHUB_REPOSITORY, set by Actions)."""
    env = dict(os.environ, GH_TOKEN=os.environ["GITHUB_TOKEN"])
    repo = os.environ["GITHUB_REPOSITORY"]
    subprocess.run(["gh", "release", "create", tag, str(mp4_path), "--repo", repo, "--title", tag,
                    "--notes", "auto-generated Short", "--prerelease"], check=True, env=env)
    return f"https://github.com/{repo}/releases/download/{tag}/{os.path.basename(mp4_path)}"


def via_zapier(mp4_path, meta, slot):
    hook = os.environ["ZAPIER_WEBHOOK_URL"]
    tag = "short-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    url = _release(mp4_path, tag)
    payload = {
        "title": meta["title"], "description": meta["description"], "tags": ",".join(meta["tags"]),
        "video_url": url, "privacy_status": "private",
        "publish_at": publish_iso_utc(slot) if config.PRIVACY_MODE == "schedule" else "",
        "publish_at_ist": slot.isoformat(), "notify_subscribers": "true", "made_for_kids": "false"}
    r = requests.post(hook, json=payload, timeout=60)
    r.raise_for_status()
    return {"backend": "zapier", "video_url": url, "zapier_response": r.text[:200], "publish_at": payload["publish_at"]}


def _access_token():
    r = requests.post("https://oauth2.googleapis.com/token", timeout=30, data={
        "client_id": os.environ["YT_CLIENT_ID"], "client_secret": os.environ["YT_CLIENT_SECRET"],
        "refresh_token": os.environ["YT_REFRESH_TOKEN"], "grant_type": "refresh_token"})
    r.raise_for_status()
    return r.json()["access_token"]


def via_youtube(mp4_path, meta, slot):
    token = _access_token()
    status = {"privacyStatus": "private", "selfDeclaredMadeForKids": False, "embeddable": True,
              "license": "youtube", "publicStatsViewable": True}
    if config.PRIVACY_MODE == "schedule":
        status["publishAt"] = publish_iso_utc(slot)
    body = {"snippet": {"title": meta["title"][:100], "description": meta["description"],
                        "tags": meta["tags"], "categoryId": "27", "defaultLanguage": "hi"}, "status": status}
    size = os.path.getsize(mp4_path)
    init = requests.post(
        "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status&notifySubscribers=true",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json; charset=UTF-8",
                 "X-Upload-Content-Length": str(size), "X-Upload-Content-Type": "video/mp4"},
        data=json.dumps(body), timeout=60)
    init.raise_for_status()
    with open(mp4_path, "rb") as fh:
        up = requests.put(init.headers["Location"], data=fh, timeout=1800,
                          headers={"Content-Length": str(size), "Content-Type": "video/mp4"})
    up.raise_for_status()
    vid = up.json()["id"]
    return {"backend": "youtube", "video_id": vid, "url": f"https://youtu.be/{vid}", "publish_at": status.get("publishAt", "")}


def upload(mp4_path, meta):
    slot = next_publish_time()
    if config.DRY_RUN or config.UPLOAD_BACKEND == "none":
        return {"backend": "none", "note": "dry run / no upload", "publish_at_ist": slot.isoformat()}
    fn = {"zapier": via_zapier, "youtube": via_youtube}[config.UPLOAD_BACKEND]
    res = fn(mp4_path, meta, slot)
    res["publish_at_ist"] = slot.isoformat()
    return res
