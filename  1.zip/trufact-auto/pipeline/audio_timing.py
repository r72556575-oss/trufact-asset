"""Step 3: trim silence per chunk, split each chunk into 2 sentences at the longest silence in its middle
(10 ms RMS windows), pad 0.3 s, concatenate. Each sentence = one scene."""
import json
import wave
from pathlib import Path
import numpy as np
from . import config

WIN = 0.010  # 10 ms


def read_wav(path):
    with wave.open(str(path), "rb") as w:
        sr, n = w.getframerate(), w.getnframes()
        x = np.frombuffer(w.readframes(n), dtype=np.int16).astype(np.float32)
        if w.getnchannels() > 1:
            x = x.reshape(-1, w.getnchannels()).mean(axis=1)
    return x, sr


def write_wav(path, x, sr):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(np.clip(x, -32768, 32767).astype(np.int16).tobytes())


def rms_windows(x, sr):
    n = int(sr * WIN)
    k = len(x) // n
    if k == 0:
        return np.zeros(1), n
    return np.sqrt((x[:k * n].reshape(k, n) ** 2).mean(axis=1)), n


def trim_silence(x, sr, rel=0.02, keep=0.04):
    r, n = rms_windows(x, sr)
    thr = max(r.max() * rel, 30.0)
    idx = np.where(r > thr)[0]
    if len(idx) == 0:
        return x
    a = max(0, int((idx[0] * n) - keep * sr))
    b = min(len(x), int(((idx[-1] + 1) * n) + keep * sr))
    return x[a:b]


def split_at_longest_silence(x, sr, lo=0.2, hi=0.8, rel=0.03):
    """Return (first, second) split in the middle of the clip at the longest quiet run (or quietest window)."""
    r, n = rms_windows(x, sr)
    thr = max(r.max() * rel, 30.0)
    a, b = int(len(r) * lo), int(len(r) * hi)
    best_len, best_mid, run_start = 0, None, None
    for i in range(a, b + 1):
        quiet = i < b and r[i] < thr
        if quiet and run_start is None:
            run_start = i
        if (not quiet) and run_start is not None:
            ln = i - run_start
            if ln > best_len:
                best_len, best_mid = ln, (run_start + i) // 2
            run_start = None
    if best_mid is None:  # no real silence found: cut at the quietest window in the middle
        best_mid = a + int(np.argmin(r[a:b + 1]))
    cut = best_mid * n
    return x[:cut], x[cut:]


def build_voice(chunk_paths, out_wav, pad=None):
    """Returns a dict with sentence timings (seconds) and writes the concatenated voice.wav."""
    pad = config.SENTENCE_PAD if pad is None else pad
    pieces, sr = [], None
    for p in chunk_paths:
        x, sr_ = read_wav(p)
        sr = sr or sr_
        assert sr_ == sr, "all chunks must share the sample rate"
        x = trim_silence(x, sr)
        first, second = split_at_longest_silence(x, sr)
        pieces += [trim_silence(first, sr), trim_silence(second, sr)]
    silence = lambda s: np.zeros(int(sr * s), dtype=np.float32)
    parts, sentences, t = [silence(config.LEAD_IN)], [], config.LEAD_IN
    for i, piece in enumerate(pieces):
        d = len(piece) / sr
        sentences.append({"i": i, "s": round(t, 3), "e": round(t + d, 3)})
        parts += [piece, silence(pad)]
        t += d + pad
    parts.append(silence(config.TAIL))
    total = t + config.TAIL
    write_wav(out_wav, np.concatenate(parts), sr)
    timing = make_timing(sr, total, sentences)
    Path(out_wav).with_suffix(".json").write_text(json.dumps(timing, indent=1))
    return timing


def make_timing(sr, total, sentences):
    # scene i runs from the start of sentence i (scene 0 from 0) to the start of sentence i+1
    scenes = []
    for i, s in enumerate(sentences):
        a = 0.0 if i == 0 else s["s"] - 0.05
        b = total if i == len(sentences) - 1 else sentences[i + 1]["s"] - 0.05
        scenes.append({"i": i, "a": round(a, 3), "b": round(b, 3),
                       "fa": int(round(a * config.FPS)), "fb": int(round(b * config.FPS)) - 1})
    return {"sr": sr, "duration": round(total, 3), "frames": int(round(total * config.FPS)),
            "sentences": sentences, "scenes": scenes}


def fit_to_target(wav_path, timing, target=None, lo=0.85, hi=1.25):
    """Make the voice ~target seconds (default 45) by a pitch-preserving tempo change (ffmpeg atempo).
    Rewrites wav_path and returns the new timing. Outside lo..hi the clip is left alone (caller should warn)."""
    import subprocess
    target = target or config.TARGET_SECONDS
    f = timing["duration"] / target          # >1 = voice too long -> speed up
    if abs(f - 1) < 0.02 or not (lo <= f <= hi):
        return timing
    tmp = Path(wav_path).with_name("voice_tempo.wav")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(wav_path), "-filter:a", f"atempo={f:.5f}", str(tmp)], check=True)
    tmp.replace(wav_path)
    sents = [{"i": s["i"], "s": round(s["s"] / f, 3), "e": round(s["e"] / f, 3)} for s in timing["sentences"]]
    new = make_timing(timing["sr"], timing["duration"] / f, sents)
    Path(wav_path).with_suffix(".json").write_text(json.dumps(new, indent=1))
    return new
