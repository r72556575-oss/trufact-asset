"""Step 4b: project setup (kit/tools/setup.sh), test render, full render in parallel shards on every 2nd frame,
then duplicate to 30 fps."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
from PIL import Image, ImageStat
from . import config


def setup_project(project: Path):
    if project.exists():
        shutil.rmtree(project)
    subprocess.run(["bash", str(config.KIT / "tools" / "setup.sh"), str(project)], check=True)
    shutil.copy(config.ROOT / "tools" / "render.mjs", project / "render.mjs")  # same file as the kit's, kept in sync


def _run_render(project: Path, outdir: Path, spec: str, step=1, resume=False):
    env = dict(os.environ, WEB=str(project / "web"))
    if resume:
        env["RESUME"] = "1"
    cmd = ["node", str(project / "render.mjs"), str(outdir), spec, str(step), "0.94"]
    return subprocess.Popen(cmd, cwd=project, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)


def render_test(project: Path, total_frames: int = None):
    """3 frames: first / middle / last. Fails on page errors or blank images."""
    import json, re
    total = total_frames or _total_from_story(project)
    frames = [0, total // 2, total - 1]
    out = project / "work" / "test_frames"
    shutil.rmtree(out, ignore_errors=True)
    p = _run_render(project, out, ",".join(map(str, frames)))
    log, _ = p.communicate(timeout=900)
    if p.returncode != 0 or "ERR" in log or "page error" in log:
        return False, log
    for f in frames:
        img = Image.open(out / f"f{f:04d}.jpg").convert("L")
        if ImageStat.Stat(img).stddev[0] < 8:  # blank / flat frame
            return False, f"frame {f} looks blank (stddev too low)\n" + log
    return True, log


def _total_from_story(project: Path) -> int:
    import re
    m = re.search(r"TOTAL\s*=\s*(\d+)", (project / "web" / "story.js").read_text())
    return int(m.group(1))


def render_all(project: Path, total: int):
    frames_dir = project / "frames"
    raw = project / "work" / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    workers = config.RENDER_WORKERS or max(1, min(4, os.cpu_count() or 1))
    step = config.RENDER_STEP
    wanted = list(range(0, total, step))
    if wanted[-1] != total - 1:
        wanted.append(total - 1)
    shards = [wanted[i::workers] for i in range(workers)]
    for attempt in range(3):  # RESUME=1 lets a failed shard continue
        procs = []
        for sh in shards:
            if not sh:
                continue
            spec = ",".join(map(str, sh))
            procs.append(_run_render(project, raw, spec, 1, resume=True))
        bad = False
        for p in procs:
            log, _ = p.communicate()
            print(log[-400:])
            bad |= p.returncode != 0
        missing = [f for f in wanted if not (raw / f"f{f:04d}.jpg").exists()]
        if not missing:
            break
        print(f"render attempt {attempt + 1}: {len(missing)} frames missing, resuming")
    else:
        raise RuntimeError("render incomplete after 3 attempts")
    # duplicate to 30 fps: frame f takes the nearest rendered frame at or before it
    frames_dir.mkdir(exist_ok=True)
    rendered = sorted(wanted)
    j = 0
    for f in range(total):
        while j + 1 < len(rendered) and rendered[j + 1] <= f:
            j += 1
        shutil.copyfile(raw / f"f{rendered[j]:04d}.jpg", frames_dir / f"f{f:04d}.jpg")
    return frames_dir
