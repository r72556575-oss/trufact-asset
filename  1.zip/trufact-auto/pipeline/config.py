"""All settings. Everything can be overridden with environment variables / GitHub Actions variables."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORK = Path(os.getenv("WORK_DIR", ROOT / "work"))
OUT = Path(os.getenv("OUT_DIR", ROOT / "out"))
HISTORY = ROOT / "history" / "topics.json"
KIT = ROOT / "kit"

# ---- Gemini ----
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"
TEXT_MODEL = os.getenv("GEMINI_TEXT_MODEL", "gemini-2.5-flash")
TTS_MODEL = os.getenv("TTS_MODEL", "gemini-3.1-flash-tts-preview")
TTS_FALLBACK_MODELS = [m.strip() for m in os.getenv("TTS_FALLBACK_MODELS", "gemini-2.5-flash-preview-tts").split(",") if m.strip()]
TTS_VOICE = os.getenv("TTS_VOICE", "Puck")  # young male voice
TTS_PROMPT = ("Read the following Hindi text exactly as written, nothing added. "
              "Young male voice, energetic, curious, punchy storyteller, brisk pace:")

# ---- Story author (writes kit/web/story.js). 'anthropic' needs ANTHROPIC_API_KEY, otherwise Gemini is used ----
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-opus-5-5")
STORY_GEMINI_MODEL = os.getenv("STORY_GEMINI_MODEL", "gemini-2.5-pro")
STORY_MAX_TRIES = int(os.getenv("STORY_MAX_TRIES", "3"))

# ---- Video ----
FPS = 30
RENDER_STEP = int(os.getenv("RENDER_STEP", "2"))      # render every 2nd frame, duplicate to 30 fps
RENDER_WORKERS = int(os.getenv("RENDER_WORKERS", "0"))  # 0 = auto (cpu count, max 4)
TARGET_SECONDS = float(os.getenv("TARGET_SECONDS", "45"))  # every video is ~45 s
NUM_SENTENCES = 10                                      # 10 beats, 5 TTS chunks x 2 sentences
MIN_HI_WORDS, MAX_HI_WORDS = 115, 170                   # checked BEFORE spending TTS quota
MUSIC_GAIN = float(os.getenv("MUSIC_GAIN", "1.4"))
SFX_GAIN = float(os.getenv("SFX_GAIN", "0.5"))
SENTENCE_PAD = 0.3                                      # seconds of silence after each sentence
LEAD_IN = 0.15
TAIL = 0.5

# ---- Upload ----
UPLOAD_BACKEND = os.getenv("UPLOAD_BACKEND", "zapier")   # zapier | youtube | none
PRIVACY_MODE = os.getenv("PRIVACY_MODE", "schedule")     # schedule (private + publishAt) | private (no publishAt)
PUBLISH_HOUR_IST = int(os.getenv("PUBLISH_HOUR_IST", "19"))
PUBLISH_MIN_IST = int(os.getenv("PUBLISH_MIN_IST", "30"))
MIN_LEAD_MINUTES = int(os.getenv("MIN_LEAD_MINUTES", "20"))  # if the slot is closer than this, use tomorrow's slot
DRY_RUN = os.getenv("DRY_RUN", "0") == "1"

CATEGORIES = [
    "science", "history", "India", "space", "human body", "nature and animals",
    "mystery (documented, not legends)", "inventions", "world records and geography", "psychology",
]
