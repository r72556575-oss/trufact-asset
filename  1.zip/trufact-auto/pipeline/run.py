"""Orchestrator:  python -m pipeline.run   (env: TOPIC_OVERRIDE, DRY_RUN=1, UPLOAD_BACKEND, PRIVACY_MODE ...)"""
import json
import os
import shutil
from datetime import datetime, timezone
from . import config, topic, tts, audio_timing, sound, story_author, render, post, upload


def main():
    config.WORK.mkdir(parents=True, exist_ok=True)
    config.OUT.mkdir(parents=True, exist_ok=True)
    log = lambda m: print(f"[{datetime.now(timezone.utc):%H:%M:%S}] {m}", flush=True)

    log("1/7 topic + verified script")
    script = topic.make_topic(os.getenv("TOPIC_OVERRIDE", ""))
    (config.OUT / "script.json").write_text(json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8")
    log(f"   {script['category']}: {script['title']}")

    log("2/7 Gemini TTS (5 chunks, Hindi voice)")
    chunks = tts.synth_chunks([s["hi"] for s in script["sentences"]], config.WORK / "tts")

    log("3/7 trim / split / pad -> voice.wav, fit to target length")
    timing = audio_timing.build_voice(chunks, config.WORK / "voice.wav")
    raw_len = timing["duration"]
    timing = audio_timing.fit_to_target(config.WORK / "voice.wav", timing)
    shutil.copy(config.WORK / "voice.wav", config.OUT / "voice.wav")
    log(f"   voice {raw_len:.1f}s -> video {timing['duration']:.1f}s (target {config.TARGET_SECONDS:.0f}s), {timing['frames']} frames")
    if abs(timing["duration"] - config.TARGET_SECONDS) > 4:
        log("   WARNING: length is more than 4 s away from the target; the Hindi script was too short/long for tempo fitting")

    log("3b/7 background music + sound effects")
    mix_wav = config.WORK / "mix_raw.wav"
    levels = sound.make_mix(config.WORK / "voice.wav", mix_wav, timing, script.get("panels", []), script["title"])
    shutil.copy(mix_wav, config.OUT / "mix_raw.wav")
    log(f"   levels {levels}")

    log("4/7 project setup + story.js + render")
    project = config.WORK / "project"
    render.setup_project(project)
    story_author.author(script, timing, project, lambda p: render.render_test(p, timing["frames"]))
    frames_dir = render.render_all(project, timing["frames"])

    log("5/7 captions + panels + mux (voice + music + sfx)")
    mp4 = config.OUT / "short.mp4"
    post.encode(frames_dir, timing["frames"], mix_wav, mp4,
                [s["en"] for s in script["sentences"]], timing, script.get("panels", []))

    log("6/7 upload")
    res = upload.upload(mp4, {"title": script["title"] + " #Shorts" if "#shorts" not in script["title"].lower() else script["title"],
                              "description": script["description"], "tags": script["tags"]})
    (config.OUT / "upload.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
    log(f"   {res}")

    if not config.DRY_RUN:  # remember the fact so it is never repeated
        h = topic.load_history()
        h.append({"date": datetime.now(timezone.utc).strftime("%Y-%m-%d"), "category": script["category"],
                  "title": script["title"], "fact": script.get("fact", "")})
        topic.save_history(h)
    log("7/7 done")


if __name__ == "__main__":
    main()
