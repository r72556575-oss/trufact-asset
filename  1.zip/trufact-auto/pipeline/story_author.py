"""Step 4a: an LLM writes web/story.js (shot plan, cameras, actors) for today's narration, using the user's
cartoon-short-kit as the specification. Every attempt is validated in seconds (tools/validate_story.mjs) and
by rendering 3 test frames; errors are fed back for a retry.

WEAKEST LINK: the engine world is a hand-built diorama (Roman bridge + Roman cast). The LLM can re-stage it,
but it cannot invent new 3D assets. Expect the look to stay inside that world."""
import json
import re
import subprocess
from pathlib import Path
import requests
from . import config, gemini

SYSTEM = """You are the director/animator for a vertical cartoon Short. You write ONE file: web/story.js for the
'cartoon-short-kit' engine. Output ONLY the complete file inside a single ```js fence, no commentary.

Hard rules:
- Keep the exact export contract of the example story.js: FPS, TOTAL, DECK, SHOTS, shotAt, smooth, LIGHTS, lightFor,
  camAt, dofAt, worldAt, actorsAt, fxAt.  TOTAL and the SHOTS frame ranges MUST match the scene table you are given
  (SHOTS contiguous from 0 to TOTAL-1, one shot per scene, ids unique).
- Use ONLY things that exist in the engine files shown (main.js world flags, roman.js cast keys/options/fx helpers,
  motion helpers). Do not call T.* functions that are not defined in roman.js / the toon base. Do not invent assets.
- Re-stage the existing world to tell today's fact visually: pick camera moves, expressions, props/fx per scene that
  match each sentence's meaning (hook -> close-up, reveal -> push-in, twist -> shake/flash, etc.).
- Every camera/dof/world value must be finite for every frame. No randomness (Math.random) - frames must be deterministic.
- Keep it compact. Do not add comments longer than one line.
"""


def _read(p):
    return Path(p).read_text(encoding="utf-8")


def build_prompt(script, timing, previous_error=None):
    scenes = []
    for sc, s in zip(timing["scenes"], script["sentences"]):
        scenes.append(f'scene {sc["i"]}: frames {sc["fa"]}-{sc["fb"]}  (English: "{s["en"]}")')
    kit = config.KIT
    parts = [
        f"README:\n{_read(kit / 'README.md')}",
        f"engine/main.js:\n{_read(kit / 'engine/main.js')}",
        f"engine/roman.js:\n{_read(kit / 'engine/roman.js')}",
        f"engine/motion.js:\n{_read(kit / 'engine/motion.js')}",
        f"EXAMPLE web/story.js (a finished story for another topic):\n{_read(kit / 'example/soldier/story.js')}",
        f"TODAY: fact = {script.get('fact', '')}\nFPS=30, TOTAL={timing['frames']}.\nScene table:\n" + "\n".join(scenes),
    ]
    if previous_error:
        parts.append(f"YOUR PREVIOUS ATTEMPT FAILED. Fix it and return the full file again. Error:\n{previous_error}")
    return "\n\n=====\n\n".join(parts)


def _call_anthropic(prompt):
    r = requests.post("https://api.anthropic.com/v1/messages", timeout=600, headers={
        "x-api-key": config.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": config.CLAUDE_MODEL, "max_tokens": 16000, "system": SYSTEM,
              "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    return "".join(b.get("text", "") for b in r.json()["content"])


def _call_gemini(prompt):
    resp = gemini.generate(config.STORY_GEMINI_MODEL, {
        "systemInstruction": {"parts": [{"text": SYSTEM}]},
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.4, "maxOutputTokens": 32000}}, timeout=600)
    return gemini.text_of(resp)


def _extract_js(text):
    m = re.search(r"```(?:js|javascript)?\s*(.*?)```", text, re.S)
    return (m.group(1) if m else text).strip()


def author(script, timing, project_dir: Path, render_test):
    """project_dir/web/story.js is written. render_test(project_dir) -> (ok, message) renders 3 test frames."""
    err = None
    story = project_dir / "web" / "story.js"
    for attempt in range(1, config.STORY_MAX_TRIES + 1):
        prompt = build_prompt(script, timing, err)
        text = _call_anthropic(prompt) if config.ANTHROPIC_API_KEY else _call_gemini(prompt)
        story.write_text(_extract_js(text), encoding="utf-8")
        v = subprocess.run(["node", str(config.ROOT / "tools" / "validate_story.mjs"), str(story), str(timing["frames"])],
                           capture_output=True, text=True)
        if v.returncode != 0:
            err = "validate_story.mjs: " + (v.stdout or v.stderr)[-1500:]
            print(f"[story attempt {attempt}] validation failed: {err}")
            continue
        ok, msg = render_test(project_dir)
        if ok:
            print(f"[story attempt {attempt}] OK")
            return story
        err = "test render: " + msg[-1500:]
        print(f"[story attempt {attempt}] render test failed: {err}")
    raise RuntimeError("story.js could not be authored: " + str(err))
